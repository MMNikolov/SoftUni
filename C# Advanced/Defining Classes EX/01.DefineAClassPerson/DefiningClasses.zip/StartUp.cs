﻿using DefiningClasses;
using System;

Person person = new Person()
{
    Name = "Petur",
    Age = 12
};
