﻿namespace GenericArrayCreator
{
    public class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = ArrayCreator.Create(50, 3);
        }
    }
}