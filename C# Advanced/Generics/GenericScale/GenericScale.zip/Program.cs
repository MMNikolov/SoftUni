﻿namespace GenericScale
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}