﻿namespace Calisthenix.Server.Models.DTOs
{
    public class CreateWorkoutDTO
    {
        public string Name { get; set; } = null!;
    }
}
