﻿namespace Calisthenix.Server.Models.DTOs
{
    public class UserDTO
    {
        public string Username { get; set; } = null!;
        public string Password { get; set; } = null!;
    }
}
