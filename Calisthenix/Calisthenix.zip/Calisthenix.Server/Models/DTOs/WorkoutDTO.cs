﻿namespace Calisthenix.Server.Models.DTOs
{
    public class WorkoutDTO
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}
