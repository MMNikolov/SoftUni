﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=DESKTOP-PP7HKGS\\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
