﻿namespace CarDealer.DTOs
{
    public class supplierDTO
    {
        public string Name { get; set; }
        public bool IsImported { get; set; }

    }
}
