﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-PP7HKGS\SQLEXPRESS;Database=CarDealer;Integrated Security=True";
    }
}
