﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = 
            @"Server=DESKTOP-PP7HKGS\SQLEXPRESS;Database=Trucks;Integrated Security=True";
    }
}
